# Topsis-Aastha-102316009

Python package for TOPSIS ranking.

Install:
pip install Topsis-Aastha-102316009

Run:
topsis data.csv 1,1,1 +,+,+ result.csv
