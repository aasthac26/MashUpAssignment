import sys
import pandas as pd
import numpy as np
import os

def error(msg):
    print("Error:", msg)
    sys.exit(1)

def main():

    # ✅ Check correct number of parameters
    if len(sys.argv) != 5:
        error("Usage: python topsis.py <inputFile> <weights> <impacts> <outputFile>")

    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]

    # ✅ File not found handling
    if not os.path.exists(input_file):
        error("File not found")

    # ✅ Split weights & impacts by comma
    weights = weights.split(',')
    impacts = impacts.split(',')

    # ✅ Read file (csv or excel)
    try:
        if input_file.endswith(".xlsx"):
            df = pd.read_excel(input_file)
        else:
            df = pd.read_csv(input_file)
    except:
        error("Unable to read input file")

    # ✅ Minimum columns check
    if df.shape[1] < 3:
        error("Input file must contain 3 or more columns")

    # ✅ Numeric column validation
    try:
        data = df.iloc[:, 1:].astype(float).values
    except:
        error("From 2nd to last columns must be numeric")

    # ✅ Weights & impacts length check
    if len(weights) != len(impacts) or len(weights) != data.shape[1]:
        error("Weights/impacts must match number of numeric columns")

    # ✅ Impact validation
    for i in impacts:
        if i not in ['+', '-']:
            error("Impacts must be either + or -")

    weights = np.array(weights, float)

    # ======================
    # ✅ TOPSIS Calculation
    # ======================

    # normalization
    norm = data / np.sqrt((data**2).sum(axis=0))

    # weighted normalization
    weighted = norm * weights

    best = []
    worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            best.append(weighted[:, i].max())
            worst.append(weighted[:, i].min())
        else:
            best.append(weighted[:, i].min())
            worst.append(weighted[:, i].max())

    best = np.array(best)
    worst = np.array(worst)

    # distance from ideal
    s_plus = np.sqrt(((weighted - best)**2).sum(axis=1))
    s_minus = np.sqrt(((weighted - worst)**2).sum(axis=1))

    score = s_minus / (s_plus + s_minus)

    # ranking
    rank = score.argsort()[::-1] + 1

    # add to dataframe
    df["Topsis Score"] = score
    df["Rank"] = rank

    # save output
    if output_file.endswith(".xlsx"):
        df.to_excel(output_file, index=False)
    else:
        df.to_csv(output_file, index=False)

    print("✅ Result saved to:", output_file)


if __name__ == "__main__":
    main()
